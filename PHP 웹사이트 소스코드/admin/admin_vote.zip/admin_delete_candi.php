<html>
    <head>
        <title>admin 관리 페이지</title>
        <meta charset="utf-8" >
    </head>
	후보 삭제 페이지<br />
		<br>
		<br>
		<hr>
	<body>
      <br>
      <form method='post' action='admin_vote_delete_candi.php'>
         삭제할 후보 번호 : <input type="text" name="no" size = "30" maxlength = "30"/> <br />
      <input type="submit" value="삭제하기" />
	</body>
</html>