﻿<!DOCTYPE>
<?php
$con=mysqli_connect("localhost","root","jongji","votingsystem"); 
//$con=mysqli_connect("localhost","root","920910","votingsystem");   
mysqli_set_charset($con,"utf8");

if (mysqli_connect_errno($con))  
{  
   echo "Failed to connect to MySQL: " . mysqli_connect_error();  
}

if(!isset($_GET["survey_id"])){
	echo "Invalid value input";
	exit();
}

$survey_id = $_GET["survey_id"];
$sql = "SELECT survey_id, survey_name, survey_short_content, survey_content FROM admin_survey WHERE survey_id = '$survey_id'";

$result = mysqli_query($con, $sql) or die(mysqli_error($con));
//$row = $result->fetch_assoc();
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

$value0 = $row["survey_id"]; // survey_id
$value1 = $row["survey_name"]; // survey_name
$value2 = $row["survey_short_content"]; // survey_shortcontent
$value3 = $row["survey_content"]; // survey_content

//$result = mysql_query($sql, $bd) or die("SQL 에러");
//$row = mysql_fetch_array($result);
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<!-- <link rel="stylesheet" type="text/css" href="read.css"> -->
	<title>설문조사</title>
</head>
<body>
	<div id="read">
		<div id='survey_view'>
		<h3 id='title'>제목 : <?php echo $value1; ?></h3>
			<p>글 번호 : <?php echo $value0; ?></p>
			<p>주제 : <?php echo $value2; ?></p>
			<p>내용</p>
			<p id="content"><?php echo $row['survey_content'] ?></p>
			<!--<p>답변</p>
			<textarea cols="50" rows="20" name="survey_response"></textarea> <br>
			-->
			<form action="survey_response.php" method="GET">
				<input type="submit" value="설문 완료">
			</form>
			<form action="survey_main.php">
				<input type="submit" value="목록">
			</form>
		</div>
	</div>
</body>
</html>